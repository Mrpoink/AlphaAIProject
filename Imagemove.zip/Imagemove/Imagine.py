from APIGEN import modeli
import PIL.Image
from Attempt import to_markdown


user_prom = input("Enter Prompt: ")
user_file = input("Enter file name: ")
img = PIL.Image.open(user_file)
response = modeli.generate_content([user_prom, img], stream=True)
response.resolve()
to_markdown(response.text)
