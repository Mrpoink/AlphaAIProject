#!/bin/bash

echo "Enter File Path"
read path
name=$(basename $path)

new_path=$(echo $path | tr -d "'")

echo $new_path

cp $new_path /path/to/AlphaAI/venv

###source /path/to/AlphaAI/bin/activate

###python3 /path/to/AlphaAI/Imagine.py

