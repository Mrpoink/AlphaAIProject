#!/bin/bash

sudo apt install python3
sudo apt install python3-pip
sudo apt install python3-venv

python3 -m venv ~/Documents

source ~/Documents/bin/activate

pip install google-generativeai

pip install pillow

sudo chmod +x install.sh

echo ALL DONE
