import discord
from datetime import datetime
from APIGEN import model
file1 = open("/home/user/AlphaAIv1.2/venv/NEWhistory.txt", "r")
file = open("/home/user/AlphaAIv1.2/venv/NEWhistory.txt", "a")

discord_token = 'Discord-Bot-Token'
chat = model.start_chat(history=[])


user_id = 1068

intents = discord.Intents.default()
client = discord.Client(intents=intents)

conversation_history = []


def model(user_message):
    response = chat.send_message(
        user_message, stream=True)
    response.resolve()
    return response.text


def time():
    now = datetime.now()
    now_string = now.strftime("%Y/%m/%d %H:%M:%S")
    return "." + now_string + "."


def remove_time(text, key):
    index = text.find(key)
    if index is True:
        result = text[:index]
    else:
        result = text

    return result

@client.event
async def on_ready():
    conversation = "These are laws, given to you for your purpose and duty: "
    for lin in file1.readlines():
        conversation = conversation + ", " + lin
    response = chat.send_message(conversation, stream=True)
    response.resolve()
    print(f'Logged in. (ID: {user_id}')


@client.event
async def on_message(message):
    if message.author.bot:
        return
    else:
        user_message = message.content + time()
    test = model(user_message)
    await message.channel.send(remove_time(test, ".2"))
    conversation_history.append((user_message, test))

client.run(discord_token)
for line in conversation_history:
    file.write(f"{line}\n")
