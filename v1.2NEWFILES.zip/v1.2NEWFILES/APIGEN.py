import google.generativeai as genai
from google.generativeai.types import HarmCategory, HarmBlockThreshold
API_KEY = "Your-API-Key-Here"

genai.configure(api_key="Your-API-Key-Here")
model = genai.GenerativeModel('gemini-pro', safety_settings={
    HarmCategory.HARM_CATEGORY_HATE_SPEECH: HarmBlockThreshold.BLOCK_NONE,
    HarmCategory.HARM_CATEGORY_HARASSMENT: HarmBlockThreshold.BLOCK_NONE,
    HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT: HarmBlockThreshold.BLOCK_NONE,
    HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT: HarmBlockThreshold.BLOCK_NONE,
})
modeli = genai.GenerativeModel('gemini-pro-vision')
