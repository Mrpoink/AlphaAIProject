import textwrap
from APIGEN import model
from IPython.display import Markdown
file1 = open('/home/user/AlphaAIv1.2/venv/Context.txt', 'r')
file = open("/home/user/AlphaAIv1.2/venv/history.txt", "a")


def to_markdown(text):
    text = response.text
    text = text.replace('•', ' *')
    return Markdown(textwrap.indent(text, '> ', predicate=lambda _: True))


chat = model.start_chat(history=[])


newHistory = []
for line in file1.readlines():
    newHistory.append(line)
for lin in newHistory:
    response = chat.send_message(lin, stream=True)
    response.resolve()
print(newHistory)


print("Welcome to Gemini, Please enter the prompt or menu for menu options")
print("As always, you can enter q to quit at any time!")


while True:
    userin = input("Enter prompt: ")
    if userin == "q":
        for line in chat.history:
            file.write(f"{line}\n")
        file.close()
        exit()

    elif userin == "menu":
        print("Image")
        print("Document Scanner")
        menin = input("Enter: ")
        if menin == "Image":
            import ImageScan as image
            response = image.ImageScan()
            to_markdown(response)
        elif menin == "Document Scanner":
            import DocumentScan as doc
            response = doc.DocumentScan()
            to_markdown(response)

    else:
        response = chat.send_message(userin, stream=True)

    if response == ValueError:
        response.prompt_feedback()
        break
    else:
        for chunk in response:
            print(chunk.text)
        print("_"*80)
        to_markdown(response)
