import google.generativeai as genai
API_KEY = "Your-Api-key-here"

file = open("/home/user/AlphaAIv1.2/venv/Your-google-developer-code")

genai.configure(api_key="OAuth-Code-Find-From-Developer-Console-Google")
file1 = open('/home/user/AlphaAIv1.2/venv/Context.txt', 'r')
history = []
for line in file1.readlines():
    history.append(line)
model = 'models/Friday'
name = 'Friday'
operation = genai.create_tuned_model(
    source_model='models/gemini-1.0-pro-001',
    training_data=[],
    id=name,
    batch_size=4,
    learning_rate=0.001,
)
modeli = genai.get_tuned_model(f'tunedModels/{name}')
print(modeli.state)
