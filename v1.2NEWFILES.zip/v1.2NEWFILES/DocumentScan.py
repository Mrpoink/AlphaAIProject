import textwrap
import fitz
from APIGEN import model


def DocumentScan():
    whole = ""
    user_input = input("Enter prompt: ")
    user_file = input("Enter File Path: ")

    if "'" in user_file:
        user_file = user_file.replace("'", "")
    with fitz.open(user_file) as doc:
        for page in doc:
            rekt = page.get_text()
            whole = whole + rekt
            rektwhole = user_input + ": " + whole
            response = model.generate_content(rektwhole)
    return response
