from APIGEN import modeli
import PIL.Image


def ImageScan():
    user_prom = input("Enter Prompt: ")
    user_file = input("Enter file path: ")
    if "'" in user_file:
        user_file = user_file.replace("'", "")
    img = PIL.Image.open(user_file)
    response = modeli.generate_content([user_prom, img], stream=True)
    response.resolve()
    return response
