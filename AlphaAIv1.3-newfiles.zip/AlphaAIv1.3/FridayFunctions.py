import time as timex
import json
import requests
from googlesearch import search


def tell_time():
    time_string = timex.strftime("%Y-%m-%d %H:%M:%S", timex.localtime())
    return time_string

def write_to_file():
    file_csv = open('history.csv', 'r')
    file_json = open('history.json', 'w')
    messages = []
    i = 0
    for line in file_csv:
        i += i
        print(f"line: {i}")
        print(line)
        line = line.strip()
        if line:
            message = json.dumps(line)
            dumped_message = json.loads(message)
            print(dumped_message)
            messages.append(dumped_message)
    json.dump(messages, file_json, indent=2)

def search_web(query: str, num_results: int):
    results = []
    for result in search(query, num_results=num_results):
        results.append(result)
    return results

def webpage_open(link: str):
    response = requests.get(link)
    content = response.text
    return content

def text_document_read(filename: str):
    text = ""
    with open(filename, 'r') as f:
        for line in f:
            text = text + " " + line
    return text